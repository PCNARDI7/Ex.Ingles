
package Classe;


public class ZoraYonara extends javax.swing.JFrame {

    
    public ZoraYonara() {
        initComponents();
        String aries = "<html><center>Aries people are creative, adaptive, and insightful. They can also be strong-willed and spontaneous (sometimes to a fault).<center><html> ";
        
        String taurus = "<html><center>Taurus zodiac signs and meanings, like the animal that represents them, is all about strength, stamina and will. Stubborn by nature, the Taurus will stand his/her ground to the bitter end (sometimes even irrationally so).<center><html>";
        
        String gemini = "<html><center>Flexibility, balance and adaptability are the keywords for the Gemini.<center><html>";
        
        String cancer = "<html><center>Cancerians love home-life, family and domestic settings. They are traditionalists, and enjoy operating on a fundamental level.<center><html> ";
        
        String leo = "<html><center>The zodiac signs and meanings of Leo is about expanse, power and exuberance.<center><html>";
        
        String virgo = "<html><center>Virgo’s have keen minds, and are delightful to talk with, often convincing others of outlandish tales with ease and charm. Virgo’s are inquisitive and are very skilled at drawing information from people.<center><html> ";
        
        String libra = "<html><center>As their zodiac signs and meanings would indicate, Libra’s are all about balance, justice, equanimity and stability. <center><html>";
        
        String scorpio = "<html><center>The Scorpio is often misunderstood. These personalities are bold and are capable of executing massive enterprises with cool control and confidence.<center><html>";
        
        String sagittarius = "<html><center>Here we have the philosopher among the zodiac signs and meanings. Like the Scorpio, they have great ability for focus, and can be very intense.<center><html>";
        
        String capricorn = "<html><center>Capricorn’s are also philosophical signs and are highly intelligent too. They apply their knowledge to practical matters, and strive to maintain stability and order.<center><html>";
        
        String aquarius = "<html><center>Often simple and unassuming, the Aquarian goes about accomplishing goals in a quiet, often unorthodox ways.<center><html> ";
        
        String pisces = "<html><center>Also unassuming, the Pisces zodiac signs and meanings deal with acquiring vast amounts of knowledge, but you would never know it. They keep an extremely low profile compared to others in the zodiac.<center><html> ";
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        bntCalc = new javax.swing.JButton();
        panTxt = new java.awt.Panel();
        lblTxt = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jSpinner1 = new javax.swing.JSpinner();
        jLabel16 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagem/horoscopo.jpg"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 204));
        jLabel2.setText("Please enter your astral sign - the number -->>");
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        bntCalc.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        bntCalc.setForeground(new java.awt.Color(0, 0, 204));
        bntCalc.setText("Press Button");
        bntCalc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntCalcActionPerformed(evt);
            }
        });

        panTxt.setBackground(new java.awt.Color(255, 255, 102));

        jLabel17.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel17.setText("Digite o numero de seu horóscopo e recebera a mensagem em inglês, favor traduzir para o publico");

        javax.swing.GroupLayout panTxtLayout = new javax.swing.GroupLayout(panTxt);
        panTxt.setLayout(panTxtLayout);
        panTxtLayout.setHorizontalGroup(
            panTxtLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panTxtLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panTxtLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panTxtLayout.createSequentialGroup()
                        .addComponent(lblTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 692, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 8, Short.MAX_VALUE))
                    .addComponent(jLabel17, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        panTxtLayout.setVerticalGroup(
            panTxtLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panTxtLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jLabel3.setFont(new java.awt.Font("Tahoma", 3, 48)); // NOI18N
        jLabel3.setText("Horoscope");

        jLabel4.setFont(new java.awt.Font("Arial Black", 3, 14)); // NOI18N
        jLabel4.setText("1-aries March 21 to April 19");

        jLabel5.setFont(new java.awt.Font("Arial Black", 3, 14)); // NOI18N
        jLabel5.setText("2-taurus April 20 to May 20");

        jLabel6.setFont(new java.awt.Font("Arial Black", 3, 14)); // NOI18N
        jLabel6.setText("3-gemini May 21 to June 21");

        jLabel7.setFont(new java.awt.Font("Arial Black", 3, 14)); // NOI18N
        jLabel7.setText("4-cancer June 22 to July 22");

        jLabel8.setFont(new java.awt.Font("Arial Black", 3, 14)); // NOI18N
        jLabel8.setText("5-leo July 23 to August 22");

        jLabel9.setFont(new java.awt.Font("Arial Black", 3, 14)); // NOI18N
        jLabel9.setText("6-virgo August 23 to September 22");

        jLabel10.setFont(new java.awt.Font("Arial Black", 3, 14)); // NOI18N
        jLabel10.setText("7-Libra 23 September to 22 October");

        jLabel11.setFont(new java.awt.Font("Arial Black", 3, 14)); // NOI18N
        jLabel11.setText("8-Scorpio 23 October to 21 November");

        jLabel12.setFont(new java.awt.Font("Arial Black", 3, 14)); // NOI18N
        jLabel12.setText("9-Sagittarius November 22 to December 21");

        jLabel13.setFont(new java.awt.Font("Arial Black", 3, 14)); // NOI18N
        jLabel13.setText("10-capricorn December 22 to January");

        jLabel14.setFont(new java.awt.Font("Arial Black", 3, 14)); // NOI18N
        jLabel14.setText("11-Aquarius January 20 to February");

        jLabel15.setFont(new java.awt.Font("Arial Black", 3, 14)); // NOI18N
        jLabel15.setText("12-pisces February 19 to March");

        jLabel16.setText("soudtrack by Roberta Kelly");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11)
                            .addComponent(jLabel12)
                            .addComponent(jLabel13)
                            .addComponent(jLabel14)
                            .addComponent(jLabel15)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 347, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(81, 81, 81)
                                .addComponent(jLabel16))
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(bntCalc))
                            .addComponent(jLabel1))))
                .addGap(1009, 1009, 1009))
            .addGroup(layout.createSequentialGroup()
                .addComponent(panTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                        .addComponent(jLabel16))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bntCalc))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel11))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel12))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel13))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel14))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panTxt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bntCalcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntCalcActionPerformed
       
        int valor;
        int num;
        
        num = Integer.parseInt(jSpinner1.getValue().toString());
        if(num==1){
        String res = "<html><center>Aries people are creative, adaptive, and insightful. They can also be strong-willed and spontaneous (sometimes to a fault).<center><html> ";
        lblTxt.setText(res); 
        
        }
        
        
        if(num==2){
        String res ="<html><center>Taurus zodiac signs and meanings, like the animal that represents them, is all about strength, stamina and will. Stubborn by nature, the Taurus will stand his/her ground to the bitter end (sometimes even irrationally so).<center><html>"; 
        lblTxt.setText(res);
        
        }
        
        if(num==3){
        String res ="<html><center>Flexibility, balance and adaptability are the keywords for the Gemini.<center><html>";
        lblTxt.setText(res);
        
        }
        
        if(num==4){
        String res ="<html><center>Cancerians love home-life, family and domestic settings. They are traditionalists, and enjoy operating on a fundamental level.<center><html> ";
        lblTxt.setText(res);
        
        }
        
        if(num==5){
        String res ="<html><center>The zodiac signs and meanings of Leo is about expanse, power and exuberance.<center><html>";
        lblTxt.setText(res);
        
        }
        
        if(num==6){
        String res ="<html><center>Virgo’s have keen minds, and are delightful to talk with, often convincing others of outlandish tales with ease and charm. Virgo’s are inquisitive and are very skilled at drawing information from people.<center><html> ";
        lblTxt.setText(res);
        
        }
        
        if(num==7){
        String res ="<html><center>As their zodiac signs and meanings would indicate, Libra’s are all about balance, justice, equanimity and stability. <center><html>";
        lblTxt.setText(res);
        
        }
        
        if(num==8){
        String res ="<html><center>The Scorpio is often misunderstood. These personalities are bold and are capable of executing massive enterprises with cool control and confidence.<center><html>";
        lblTxt.setText(res);
        
        }
        
        if(num==9){
        String res ="<html><center>Here we have the philosopher among the zodiac signs and meanings. Like the Scorpio, they have great ability for focus, and can be very intense.<center><html>";
        lblTxt.setText(res);
        
        }
        
        if(num==10){
        String res ="<html><center>Capricorn’s are also philosophical signs and are highly intelligent too. They apply their knowledge to practical matters, and strive to maintain stability and order.<center><html>";
        lblTxt.setText(res);
        
        }
        
        if(num==11){
        String res ="<html><center>Often simple and unassuming, the Aquarian goes about accomplishing goals in a quiet, often unorthodox ways.<center><html> ";
        lblTxt.setText(res);
        
        }
        
        if(num==12){
        String res ="<html><center>Also unassuming, the Pisces zodiac signs and meanings deal with acquiring vast amounts of knowledge, but you would never know it. They keep an extremely low profile compared to others in the zodiac.<center><html> ";
        lblTxt.setText(res);
        
        }
    }//GEN-LAST:event_bntCalcActionPerformed

   
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ZoraYonara().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bntCalc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JLabel lblTxt;
    private java.awt.Panel panTxt;
    // End of variables declaration//GEN-END:variables
}
